/* ===========================================================================
   Waymark
   =========================================================================== */

const CFG = Object.assign(
  { basemap: "opentopo", osApiKey: "", cuddlyLampBase: "" },
  window.WAYMARK_CONFIG || {}
);

const ORIGIN = { lat: 51.7447, lon: -2.2166, name: "Stroud" };   // keep in step with build_index.py
const MAX_RADIUS_KM = 90;

/* ── basemaps ──────────────────────────────────────────────────────────────
   The Leisure style — the actual 1:25 000 Explorer sheet — is published in British
   National Grid only, which is why this file carries Proj4Leaflet and why the CRS is
   chosen per profile rather than assumed. MapLibre cannot serve EPSG:27700 raster.
   Resolutions and origin below are the OS Data Hub reference values; don't tune them.  */

const BNG = () => new L.Proj.CRS(
  "EPSG:27700",
  "+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 " +
  "+ellps=airy +towgs84=446.448,-125.157,542.06,0.15,0.247,0.842,-20.489 +units=m +no_defs",
  {
    resolutions: [896, 448, 224, 112, 56, 28, 14, 7, 3.5, 1.75, 0.875, 0.4375, 0.21875, 0.109375],
    origin: [-238375.0, 1376256.0]
  }
);

const BASEMAP_PROFILES = {
  opentopo: {
    crs: L.CRS.EPSG3857,
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    options: { maxZoom: 17, subdomains: "abc" },
    zoom: 11, minZoom: 8, maxZoom: 17,
    attribution: "Map data © OpenStreetMap contributors, SRTM · Tiles © OpenTopoMap (CC-BY-SA)"
  },
  "os-outdoor": {
    crs: L.CRS.EPSG3857,
    url: "https://api.os.uk/maps/raster/v1/zxy/Outdoor_3857/{z}/{x}/{y}.png?key={key}",
    options: { maxZoom: 20 },
    zoom: 12, minZoom: 8, maxZoom: 20,
    attribution: "Contains OS data © Crown copyright and database rights " + new Date().getFullYear()
  },
  "os-leisure": {
    crs: BNG,
    // WMTS rather than ZXY: the 27700 tile matrix is served through the WMTS endpoint.
    // Verify the layer name and parameter casing against the OS Maps API technical
    // specification before the first deploy — this is the one URL most likely to bite.
    url: "https://api.os.uk/maps/raster/v1/wmts?key={key}&service=WMTS&request=GetTile" +
         "&version=2.0.0&height=256&width=256&outputFormat=image%2Fpng&style=default" +
         "&layer=Leisure_27700&tileMatrixSet=EPSG%3A27700&tileMatrix={z}&tileRow={y}&tileCol={x}",
    options: { maxZoom: 13 },
    zoom: 7, minZoom: 3, maxZoom: 13,
    attribution: "Contains OS data © Crown copyright and database rights " + new Date().getFullYear()
  }
};

/* ── state ─────────────────────────────────────────────────────────────────── */

const state = {
  walks: [],
  markers: new Map(),
  routeLayer: L.layerGroup(),
  selected: null,
  sector: null,                      // { b0, b1, r0, r1 } — set by the dial
  filters: {
    dist: 30, asc: 900, grad: 30, surf: 0, tech: 5, conf: 0,
    run: "", flags: new Set()
  }
};

let map;

/* ── geodesy ───────────────────────────────────────────────────────────────── */

const rad = d => d * Math.PI / 180;

function crowKm(a, b) {
  const R = 6371;
  const dp = rad(b.lat - a.lat), dl = rad(b.lon - a.lon);
  const h = Math.sin(dp / 2) ** 2 +
            Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

const COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                 "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
const compass = deg => COMPASS[Math.round(((deg % 360) + 360) % 360 / 22.5) % 16];

/* ── map ───────────────────────────────────────────────────────────────────── */

function initMap() {
  const p = BASEMAP_PROFILES[CFG.basemap] || BASEMAP_PROFILES.opentopo;
  const crs = typeof p.crs === "function" ? p.crs() : p.crs;

  map = L.map("map", { crs, zoomControl: false, minZoom: p.minZoom, maxZoom: p.maxZoom })
        .setView([ORIGIN.lat, ORIGIN.lon], p.zoom);

  L.control.zoom({ position: "bottomright" }).addTo(map);

  const url = p.url.replace("{key}", CFG.osApiKey);
  L.tileLayer(url, Object.assign({ attribution: p.attribution }, p.options))
   .on("tileerror", () => {
      if (CFG.basemap !== "opentopo") {
        console.warn("Basemap tiles failed. Check the OS key and its referrer lock.");
      }
   })
   .addTo(map);

  state.routeLayer.addTo(map);
  document.getElementById("attribution").textContent =
    p.attribution + " · Walk data © OpenStreetMap contributors (ODbL)";
}

function pinIcon(w, selected) {
  const low = w.confidence < 0.6;
  return L.divIcon({
    className: "",
    html: `<div class="walk-pin" data-low="${low}" data-selected="${!!selected}"></div>`,
    iconSize: [14, 14], iconAnchor: [7, 7]
  });
}

function renderMarkers() {
  state.walks.forEach(w => {
    const m = L.marker([w.lat, w.lon], { icon: pinIcon(w), title: w.name })
               .on("click", () => select(w.slug));
    state.markers.set(w.slug, m);
  });
}

/* ── filtering ─────────────────────────────────────────────────────────────── */

function inSector(w) {
  const s = state.sector;
  if (!s) return true;
  if (w.crow_km < s.r0 || w.crow_km > s.r1) return false;
  const b = ((w.bearing % 360) + 360) % 360;
  return s.b0 <= s.b1 ? (b >= s.b0 && b <= s.b1) : (b >= s.b0 || b <= s.b1);
}

function passes(w) {
  const f = state.filters;
  if (w.distance_km > f.dist) return false;
  if (w.ascent_m > f.asc) return false;
  if (f.grad < 30 && (w.gradient_pct ?? 0) > f.grad) return false;
  if ((w.soft_pct + (100 - w.sealed_pct - w.soft_pct) * 0) < f.surf) return false;
  if ((w.ratings?.technicality ?? 1) > f.tech) return false;
  if (w.confidence * 100 < f.conf) return false;
  if (f.run === "throughout" && w.runnable !== "throughout") return false;
  if (f.run === "mostly" && !["mostly", "throughout"].includes(w.runnable)) return false;
  for (const flag of f.flags) if (!w[flag]) return false;
  return inSector(w);
}

function apply() {
  let shown = 0;
  state.walks.forEach(w => {
    const ok = passes(w);
    const m = state.markers.get(w.slug);
    if (ok) { if (!map.hasLayer(m)) m.addTo(map); shown++; }
    else if (map.hasLayer(m)) map.removeLayer(m);
  });
  document.getElementById("count").textContent = shown;
  drawDots();
}

/* ── the dial ──────────────────────────────────────────────────────────────
   Every walk is a dot in polar coordinates about Stroud: angle is bearing, radius is
   distance as the crow flies. Drag across it and the bounding sector of the drag becomes
   the filter — one gesture, two dimensions. A radius slider can't do that, and nobody
   chooses a walk by radius anyway.                                                       */

const DIAL_R = 92;
const svg = id => document.getElementById(id);
const kmToPx = km => Math.min(km, MAX_RADIUS_KM) / MAX_RADIUS_KM * DIAL_R;
const pxToKm = px => px / DIAL_R * MAX_RADIUS_KM;

function polar(bearingDeg, km) {
  const a = rad(bearingDeg - 90);
  const r = kmToPx(km);
  return [r * Math.cos(a), r * Math.sin(a)];
}

function drawChrome() {
  const rings = svg("dial-rings"), ticks = svg("dial-ticks");
  rings.innerHTML = ""; ticks.innerHTML = "";

  [15, 30, 45, 60, 90].forEach(km => {
    const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    c.setAttribute("r", kmToPx(km));
    rings.appendChild(c);
  });

  ["N", "E", "S", "W"].forEach((label, i) => {
    const deg = i * 90;
    const [x1, y1] = polar(deg, MAX_RADIUS_KM * 0.92);
    const [x2, y2] = polar(deg, MAX_RADIUS_KM);
    const ln = document.createElementNS("http://www.w3.org/2000/svg", "line");
    ln.setAttribute("x1", x1); ln.setAttribute("y1", y1);
    ln.setAttribute("x2", x2); ln.setAttribute("y2", y2);
    ticks.appendChild(ln);

    const [tx, ty] = polar(deg, MAX_RADIUS_KM * 1.09);
    const t = document.createElementNS("http://www.w3.org/2000/svg", "text");
    t.setAttribute("x", tx); t.setAttribute("y", ty);
    t.textContent = label;
    ticks.appendChild(t);
  });
}

function drawDots() {
  const g = svg("dial-dots");
  g.innerHTML = "";
  state.walks.forEach(w => {
    const [x, y] = polar(w.bearing, w.crow_km);
    const c = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    c.setAttribute("cx", x); c.setAttribute("cy", y);
    c.setAttribute("data-in", passes(w));
    c.setAttribute("role", "img");
    c.setAttribute("aria-label", `${w.name}, ${w.crow_km} km ${compass(w.bearing)}`);
    c.addEventListener("click", e => { e.stopPropagation(); select(w.slug); });
    g.appendChild(c);
  });
}

function drawWedge() {
  const path = svg("dial-wedge");
  const s = state.sector;
  if (!s) { path.setAttribute("d", ""); return; }

  const [ax, ay] = polar(s.b0, s.r1), [bx, by] = polar(s.b1, s.r1);
  const [cx, cy] = polar(s.b1, s.r0), [dx, dy] = polar(s.b0, s.r0);
  const span = (s.b1 - s.b0 + 360) % 360;
  const large = span > 180 ? 1 : 0;

  path.setAttribute("d",
    `M ${ax} ${ay} A ${kmToPx(s.r1)} ${kmToPx(s.r1)} 0 ${large} 1 ${bx} ${by} ` +
    `L ${cx} ${cy} A ${kmToPx(s.r0)} ${kmToPx(s.r0)} 0 ${large} 0 ${dx} ${dy} Z`);
}

function readSector() {
  const el = svg("dial-read"), s = state.sector;
  el.textContent = s
    ? `${compass(s.b0)}–${compass(s.b1)}, ${Math.round(s.r0)}–${Math.round(s.r1)} km`
    : "All directions, any distance";
}

function initDial() {
  const el = svg("dial");
  let drag = null;

  const at = ev => {
    const r = el.getBoundingClientRect();
    const x = (ev.clientX - r.left) / r.width * 220 - 110;
    const y = (ev.clientY - r.top) / r.height * 220 - 110;
    return {
      bearing: ((Math.atan2(y, x) * 180 / Math.PI + 90) % 360 + 360) % 360,
      km: pxToKm(Math.hypot(x, y))
    };
  };

  el.addEventListener("pointerdown", ev => {
    el.setPointerCapture(ev.pointerId);
    drag = { from: at(ev), moved: false };
  });

  el.addEventListener("pointermove", ev => {
    if (!drag) return;
    const to = at(ev);
    drag.moved = true;
    const b0 = drag.from.bearing, b1 = to.bearing;
    // Take the shorter arc between the two — dragging clockwise past north should not
    // select 340 degrees of the compass.
    const cw = (b1 - b0 + 360) % 360;
    state.sector = {
      b0: cw <= 180 ? b0 : b1,
      b1: cw <= 180 ? b1 : b0,
      r0: Math.max(0, Math.min(drag.from.km, to.km)),
      r1: Math.min(MAX_RADIUS_KM, Math.max(drag.from.km, to.km))
    };
    drawWedge(); readSector(); apply();
  });

  const end = () => {
    if (drag && !drag.moved) { state.sector = null; drawWedge(); readSector(); apply(); }
    drag = null;
  };
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", end);

  document.getElementById("dial-clear").addEventListener("click", () => {
    state.sector = null; drawWedge(); readSector(); apply();
  });

  drawChrome(); drawWedge(); readSector();
}

/* ── detail ────────────────────────────────────────────────────────────────── */

async function select(slug) {
  const res = await fetch(`./data/walks/${slug}.json`);
  if (!res.ok) return;
  const w = await res.json();

  state.routeLayer.clearLayers();
  const latlngs = w.geometry.route.coordinates.map(([lon, lat]) => [lat, lon]);
  L.polyline(latlngs, { className: "route-casing" }).addTo(state.routeLayer);
  L.polyline(latlngs, { className: "route-core" }).addTo(state.routeLayer);
  map.fitBounds(L.latLngBounds(latlngs).pad(0.15));

  const f = w.facts, e = w.editorial, c = w.confidence;
  const veg = f.amenities.refreshment.find(r => ["yes", "only"].includes(r.vegan));

  document.getElementById("detail-body").innerHTML = `
    <h2>${w.name}</h2>
    <p>${e.summary}</p>

    <div class="stat-grid">
      <div><span class="k">Distance</span><span>${f.distance_km} km</span></div>
      <div><span class="k">Ascent</span><span>${f.ascent_m} m</span></div>
      <div><span class="k">Steepest</span><span>${f.max_sustained_gradient_pct ?? "—"}%</span></div>
      <div><span class="k">By right</span><span>${f.access.by_right_pct}%</span></div>
      <div><span class="k">Unsealed</span><span>${(f.surface_mix.soft_pct ?? 0) + (f.surface_mix.firm_pct ?? 0)}%</span></div>
      <div><span class="k">Confidence</span><span>${c.navigable}</span></div>
    </div>

    <h3>Character</h3><p>${e.character}</p>
    ${e.grain ? `<h3>Grain</h3><p>${e.grain}</p>` : ""}
    <h3>Conditions</h3><p>${e.conditions}</p>
    <h3>Practical</h3><p>${e.practical}</p>
    ${veg ? "" : `<p><span class="chip">no vegan option recorded</span></p>`}
    <h3>Caveats</h3><p>${e.caveats}</p>

    <h3>Confidence</h3>
    <p>${c.basis}</p>
    <p>${c.resolved
        ? `<span class="chip">resolved ${c.resolved.date}: ${c.resolved.outcome.replace(/_/g, " ")}</span>`
        : `<span class="chip" data-tone="warn">unresolved — not yet walked</span>`}</p>

    <p><small>${w.provenance.attribution.join(" · ")}</small></p>
  `;
  document.getElementById("detail").hidden = false;
  state.selected = slug;
}

/* ── wiring ────────────────────────────────────────────────────────────────── */

function initControls() {
  const bind = (id, key, fmt) => {
    const input = document.getElementById(id);
    const out = document.getElementById(id.replace("f-", "out-"));
    const sync = () => {
      state.filters[key] = Number(input.value);
      out.textContent = fmt(Number(input.value));
      apply();
    };
    input.addEventListener("input", sync);
    sync();
  };

  bind("f-dist", "dist", v => v >= 30 ? "any" : `≤ ${v} km`);
  bind("f-asc",  "asc",  v => v >= 900 ? "any" : `≤ ${v} m`);
  bind("f-grad", "grad", v => v >= 30 ? "any" : `≤ ${v}%`);
  bind("f-surf", "surf", v => v === 0 ? "any" : `≥ ${v}% unsealed`);
  bind("f-tech", "tech", v => v >= 5 ? "any" : `${v} of 5`);
  bind("f-conf", "conf", v => v === 0 ? "any" : `${v}%`);

  document.querySelectorAll("[data-flag]").forEach(cb => {
    cb.addEventListener("change", () => {
      cb.checked ? state.filters.flags.add(cb.dataset.flag)
                 : state.filters.flags.delete(cb.dataset.flag);
      apply();
    });
  });

  document.querySelectorAll("input[name=run]").forEach(r => {
    r.addEventListener("change", () => { state.filters.run = r.value; apply(); });
  });

  document.getElementById("detail-close").addEventListener("click", () => {
    document.getElementById("detail").hidden = true;
    state.routeLayer.clearLayers();
    state.selected = null;
  });

  // Bottom sheet detents on small screens.
  const rail = document.getElementById("rail");
  const grip = document.getElementById("rail-grip");
  const cycle = () => {
    const order = ["peek", "half", "full"];
    const now = rail.dataset.detent || "peek";
    rail.dataset.detent = order[(order.indexOf(now) + 1) % order.length];
  };
  grip.addEventListener("click", cycle);
  grip.addEventListener("keydown", ev => {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); cycle(); }
  });
}

async function loadCalibration() {
  const el = document.getElementById("calibration");
  try {
    const s = await (await fetch("./data/calibration.json")).json();
    if (!s.n) { el.textContent = "No walks resolved yet."; return; }
    el.innerHTML =
      `n ${s.n} · Brier ${s.brier}<br>` +
      `reliability ${s.reliability} · resolution ${s.resolution}` +
      (s.n < 10 ? "<br>below n=10, treat as decorative" : "");
  } catch {
    el.textContent = "No walks resolved yet.";
  }
}

async function main() {
  initMap();
  const data = await (await fetch("./data/walks.json")).json();
  state.walks = data.walks;
  document.getElementById("total").textContent = state.walks.length;
  renderMarkers();
  initDial();
  initControls();
  apply();
  loadCalibration();
}

main();
